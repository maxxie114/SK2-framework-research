$(':input').labelauty();

var g_jquery_upload_file_is_first_times = true;
var g_jquery_file_manager_current_dir = null;
var g_sk2_back_dir = "/var/mobile/SK2";

var g_jquery_upload_file_is_import_bak = false;

var g_full_page_progress = null;

// 修改样式
function modifyCss() {
	// $('.fileupload-buttonbar').css('margin-bottom', '0px');
	// $('.btn').css('margin-bottom', '0px');
	$('.toggle').css('margin-bottom', '0px');
	$('buttonbar').css('margin-bottom', '0px');
    $('td').css('vertical-align', 'middle');
    $('label').css('margin-bottom', '0px');
    $('label').css('padding', '5px');
    $('p').css('margin', '0 0 0px');
    $('.progress').css('margin', '0 0 0px');
    $('.progress').css('height', '14px');
    $('.size').css('margin', '0 0 0px');
}

// 加载文件列表
function loadFileList(dir) {
	if(dir == g_sk2_back_dir) {
		// 只允许上传zip
		$('#fileupload').fileupload({acceptFileTypes: /(\.|\/)(zip|zip)$/i});
	} else {
		$('#fileupload').fileupload({acceptFileTypes: /(.*)$/i});
	}
	
	$('#fileupload').fileupload({url: 'listFile?dir=' + dir});
	// Load existing files:
    $('#fileupload').addClass('fileupload-processing');
    $.ajax({
        // Uncomment the following to send cross-domain cookies:
        // xhrFields: {withCredentials: true},
        url: $('#fileupload').fileupload('option', 'url'),
        dataType: 'json',
        context: $('#fileupload')[0]
    }).always(function () {
        $(this).removeClass('fileupload-processing');
    }).done(function (result) {
        $(this).fileupload('option', 'done').call(this, $.Event('done'), {result: result});
        // 显示完成就将url设置成添加
        $('#fileupload').fileupload({url: 'uploadFile'});
        // 重新加载checkbox样式
        $(':input').labelauty();
        // 修改样式
		modifyCss();
    });
}

// 初始化代码
$(function () {
    'use strict';
    // Initialize the jQuery File Upload widget:
    $('#fileupload').fileupload({
        // Uncomment the following to send cross-domain cookies:
        // xhrFields: {withCredentials: true},
        // maxFileSize: 999000,
        // acceptFileTypes: /(\.|\/)(zip|zip)$/i, // /(\.|\/)(*|*)
        url: 'listFile?dir=/',
        completed: function (e, data) {
        	if(data.result.dir != undefined) {
	        	g_jquery_file_manager_current_dir = data.result.dir;
	        }
        	// 文件列表加载完成, 修改checkbox样式
        	$(':input').labelauty();
        	// 去重文件列表
        	if(data.result != null && data.result.files != undefined && data.result.files.length > 0) {
	        	var fileItems = $('#fileupload').find('a[download=\"' + data.result.files[0].name + '\"]');
	        	if(fileItems.length > 0) {
	        		g_jquery_upload_file_is_bat_delete_file = true;
	        		for(var i = 0; i < fileItems.length - 1; i++) {
	        			fileItems[i].parentNode.parentNode.parentNode.remove();
	        		}
	        		g_jquery_upload_file_is_bat_delete_file = false;
	        	}
	        }
        	// 修改样式
			modifyCss();
			// 判断是否有隐藏进度详情
			if($('table[role="presentation"]').find('.progress.progress-striped.active').length <= 0) {
				$('.col-lg-5.fileupload-progress.fade').css('display', 'none');
			}
			
			// 导入完成处理
			if(g_jquery_upload_file_is_import_bak) {
				onImportBakCompleted(data.result);
			}
        },
        added: function (e, data) {
	        // 添加完成动作
	        $('#fileupload').fileupload({url: 'uploadFile'});
	        // 临时添加参数
    		$('#fileupload').fileupload({
    			formData: {
					dir: g_jquery_file_manager_current_dir
				},
    		});
	        // 修改样式
			modifyCss();
    	},
    	started: function (e, data) {
	        // 添加完成动作
    	},
    	send: function(e, data) {
    		// 添加参数
    		$('#fileupload').fileupload({
    			formData: {
					dir: g_jquery_file_manager_current_dir
				},
    		});
    		// 判断是否有显示进度详情
			if($('table[role="presentation"]').find('.progress.progress-striped.active').length >= 0) {
				$('.col-lg-5.fileupload-progress.fade').css('display', 'inline');
			}
    	},
    	destroyed: function (e, data) {
	        // 删除完成动作
    	},
    });
	// 隐藏进度详情
	$('.col-lg-5.fileupload-progress.fade').css('display', 'none');
	loadFileList("/");
	
	// 绑定事件
	$("button.createDir").bind("click",function(){
		var rs = prompt("请输入目录名: ", "");
		if(rs != null && rs.trim().length > 0) {
			var data = sendSyncRequest("createDir?filePath=" + g_jquery_file_manager_current_dir + "/" + rs);
            if(data.code == 1) {
            	refreshFileList();
            } else {
	            alert("操作失败");
	        }
		}
	});
	// 备份管理
	$("button.manageBak").bind("click",function(){
		reloadFileList(g_sk2_back_dir);
	});
	// 备份导入
	$("button.importBak").bind("click",function(){
		if(g_jquery_file_manager_current_dir != g_sk2_back_dir) {
			alert("请先进入[管理备份]模块");
			return;
		}
		
		if($('table[role="presentation"]').find('.progress.progress-striped.active').length <= 0) {
			alert("请将要备份的zip拖入页面内");
			return;
		}
		
		g_jquery_upload_file_is_import_bak = true; // 需要在所有文件已上传完成后进行刷新列表
		// 临时添加参数
		$('#fileupload').fileupload({
			formData: {
				dir: g_jquery_file_manager_current_dir,
				action: "importBak"
			},
		});
		$("button.start").click();
	});
	// 备份导出
	$("button.exportBak").bind("click",function(){
		var fileNameStrs = "";
		var arr = $('#fileupload').find('.toggle:checked');
		var fileCount = 0;
		var isFolder = false;
		if(arr.length > 0 ) {
			for(var i = 0; i < arr.length; i++) {
				var obj = arr[i];
				var objFileName = $(obj.parentNode).find("a[type=\"fileItem\"]");
				var fileName = objFileName.text();
				if(fileName != "上级目录" && fileName != "..") {
					fileNameStrs += fileName;
					if(i <= arr.length - 2) {
						fileNameStrs += "|";
					}
					fileCount++;
					isFolder = objFileName.attr("filetype") == "folder";
				}
			}
			// 判断是否是单文件且非文件夹，如果是，则直接下载
			if(fileCount == 1 && !isFolder) {
				window.open("downloadFile?filePath=" + g_jquery_file_manager_current_dir + "/" + fileNameStrs);
				return;
			}
			// 直接找开窗口，也可以使用ajax进行压缩，然后返回下载的url, 再进行下载，这样可以隐藏一下压缩请求url, 但没有什么用
			// window.open("exportBak?dir=" + g_jquery_file_manager_current_dir + "&fileNames=" + fileNameStrs); 
			showFullPageProgress("正在打包中，请稍候...");
			sendAsyncRequest(
				"compressFile", 
				"POST", 
				{dir: g_jquery_file_manager_current_dir, fileNames: fileNameStrs}, 
				function(data){
					if(data.code == 1) {
						window.open("downloadFile?filePath=" + data.path);
					} else {
						alert("操作失败");
					}
					dismissFullPageProgress();
				}, 
				function(e){
					dismissFullPageProgress();
					
				}
			);
		} else {
			alert("请选择要导出的备份");
		}
	});
	// 刷新文件列表
	$("button.refresh").bind("click",function(){
		g_jquery_upload_file_is_import_bak = false;
		refreshFileList();
	});
});

function refreshFileList() {
	reloadFileList(g_jquery_file_manager_current_dir);
}

// 清空文件列表控件
function removeAllFileList() {
	// var fileItems = $('#fileupload').find('a[type=\"fileItem\"]');
	// var fileItems = $('#fileupload').find('img[alt=\"上传文件\"]');
	// if(fileItems.length > 0) {
	// 	g_jquery_upload_file_is_bat_delete_file = true;
	// 	for(var i = 0; i < fileItems.length; i++) {
	// 		fileItems[i].parentNode.parentNode.parentNode.remove();
	// 	}
	// 	g_jquery_upload_file_is_bat_delete_file = false;
	// }
	var fileItems = $('table tbody');
	if(fileItems != undefined) {
		fileItems.empty();
	}
}

// 重新加载指定目录的文件列表
function reloadFileList(dir) {
	$("#h3_dir").text(dir);
	removeAllFileList();
	loadFileList(dir);
}

function sendSyncRequest(urlStr) {
	return $.ajax({
               type: "GET",
               url: urlStr,
               dataType:"json",
               async: false
            }).responseJSON;
}

function sendAsyncRequest(urlStr, methodType, jsonData, successCallBack, failCallBack) {
	$.ajax({
		url : urlStr,
		type : methodType,
		async: true,//使用同步的方式,true为异步方式
		data : jsonData, //{'act':'addvideo', 'videoname':videoname},//这里使用json对象
		dataType:"json",
		success : function(data){
			successCallBack(data);
		},
		fail:function(e){
			failCallBack(e);
		},
		error:function(e){
			failCallBack(e);
		}
	});
}

function onImportBakCompleted(result) {
	// 刷新列表, 在所有任务已上传完成后
	if($('table[role="presentation"]').find('.progress.progress-striped.active').length <= 0) {
		refreshFileList();
		g_jquery_upload_file_is_import_bak = false;
	}
	if(!result.status) {
		alert("操作失败");
	}
}
// 全页面进度条
function showFullPageProgress(msg) {
	g_full_page_progress = getBusyOverlay('viewport',{color:'white', opacity:0.75, text:msg, style:'text-shadow: 0 0 3px black;font-weight:bold;font-size:16px;color:white'},{color:'green', size:100, type:'o'});
}

function updateFullPageProgress(msg) {
	if(g_full_page_progress != null) {
		g_full_page_progress.settext(msg);
	}
}

function dismissFullPageProgress() {
	if(g_full_page_progress != null) {
		g_full_page_progress.remove();
	}
}

